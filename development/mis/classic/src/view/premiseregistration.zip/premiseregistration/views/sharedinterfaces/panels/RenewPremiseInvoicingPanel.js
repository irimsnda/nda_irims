/**
 * Created by Kip on 11/26/2018.
 */
Ext.define('Admin.view.premiseregistration.views.sharedinterfaces.panels.RenewPremiseInvoicingPanel', {
    extend: 'Admin.view.commoninterfaces.InvoicingPanel',
    xtype: 'renewpremiseinvoicingpanel'
});
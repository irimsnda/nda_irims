/**
 * Created by Kip on 12/4/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.renew.RenewPremiseInspectionPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.RenewPremiseInspectionPanel',
    xtype: 'renewpremiseinspectionpnl'
});
/**
 * Created by Kip on 11/12/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.new.NewPremisePaymentsPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.NewPremisePaymentsPanel',
    xtype: 'newpremisepaymentspnl'
});
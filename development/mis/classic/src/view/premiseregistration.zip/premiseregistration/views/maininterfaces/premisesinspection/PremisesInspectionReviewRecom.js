/**
 * Created by Kip on 11/12/2018.
 */
Ext.define('Admin.view.premiseregistration.views.maininterfaces.premisesinspection.PremisesInspectionReviewRecom', {
    extend: 'Ext.panel.Panel',
    xtype: 'premisesinspectionreviewrecom',
    layout: 'fit',
    items: [
        {
            xtype: 'premisesinspectionreviewrecompnl'
        }
    ]
});
Ext.define('Admin.view.premiseregistration.views.maininterfaces.returns.AnnualReturnPremiseReceiving', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.main.AnnualReturnsMainPremiseReceiving',
    xtype: 'annualreturnpremiseReceiving',
    // items: [
    //     {
    //         xtype: 'annualreturnspremisereceivingwizard'
    //     }
    // ]
});
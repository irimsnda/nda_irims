/**
 * Created by Kip on 12/4/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.renew.RenewPremiseScreeningPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.RenewPremiseEvaluationPanel',
    xtype: 'renewpremisescreeningpnl'
});
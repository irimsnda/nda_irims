/**
 * Created by Kip on 12/7/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.alteration.FoodAltPremiseReceivingWizard', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.AltPremiseReceivingWizard',
    xtype: 'foodaltpremisereceivingwizard'
});
/**
 * Created by Kip on 9/26/2018.
 */
Ext.define('Admin.view.premiseregistration.views.grids.ApplicantSelectionGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicantSelectionCmnGrid',
    controller: 'premiseregistrationvctr',
    xtype: 'applicantselectiongrid'
});

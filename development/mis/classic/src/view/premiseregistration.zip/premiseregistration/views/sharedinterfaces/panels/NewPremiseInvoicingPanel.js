/**
 * Created by Kip on 11/12/2018.
 */
Ext.define('Admin.view.premiseregistration.views.sharedinterfaces.panels.NewPremiseInvoicingPanel', {
    extend: 'Admin.view.commoninterfaces.InvoicingPanel',
    xtype: 'newpremiseinvoicingpanel'
});
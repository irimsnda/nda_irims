Ext.define('Admin.view.premiseregistration.views.forms.PremiseMeetingDetailsFrm', {
    extend: 'Admin.view.commoninterfaces.views.forms.MeetingDetailsFrm',
    xtype: 'premiseMeetingDetailsFrm',
   
});
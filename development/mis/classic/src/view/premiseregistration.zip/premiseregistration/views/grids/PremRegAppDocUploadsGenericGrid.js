/**
 * Created by Kip on 2/7/2019.
 */
Ext.define('Admin.view.premiseregistration.views.grids.PremRegAppDocUploadsGenericGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicationDocUploadsGrid',
    xtype: 'premregappdocuploadsgenericgrid',
    table_name: 'tra_premises_applications'
});
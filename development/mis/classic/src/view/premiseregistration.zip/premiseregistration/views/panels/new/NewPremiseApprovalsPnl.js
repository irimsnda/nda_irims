/**
 * Created by Kip on 11/12/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.new.NewPremiseApprovalsPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.NewPremiseApprovalsPanel',
    xtype: 'newpremiseapprovalspnl'
});
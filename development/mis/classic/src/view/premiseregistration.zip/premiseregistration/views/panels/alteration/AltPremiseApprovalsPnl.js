/**
 * Created by Kip on 12/13/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.alteration.AltPremiseApprovalsPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.AltPremiseApprovalsPanel',
    xtype: 'altpremiseapprovalspnl'
});
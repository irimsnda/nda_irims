
Ext.define('Admin.view.premiseregistration.views.dashboards.PreInspectionDrugsPremRegDashWrapper', {
    extend: 'Ext.Container',
    xtype: 'preinspectiondrugspremregdashwrapper',
    layout: 'fit',
    items: [
        {
            xtype: 'preinspectiondrugspremregdash'
        }
    ]
});
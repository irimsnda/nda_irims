/**
 * Created by Kip on 12/4/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.renew.RenewPremisePaymentsPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.RenewPremisePaymentsPanel',
    xtype: 'renewpremisepaymentspnl'
});
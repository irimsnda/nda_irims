/**
 * Created by Kip on 2/7/2019.
 */
Ext.define('Admin.view.premiseregistration.views.grids.PremRegAppPrevDocUploadsGenericGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicationPrevDocUploadsGrid',
    xtype: 'premregappprevdocuploadsgenericgrid',
    table_name: 'tra_premises_applications'
});
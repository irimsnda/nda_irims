/**
 * Created by Kip on 7/11/2019.
 */
Ext.define('Admin.view.premiseregistration.views.panels.new.NewPremisePostPaymentReviewPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.NewPremisePostPaymentReviewPanel',
    xtype: 'newpremisepostpaymentreviewpnl'
});
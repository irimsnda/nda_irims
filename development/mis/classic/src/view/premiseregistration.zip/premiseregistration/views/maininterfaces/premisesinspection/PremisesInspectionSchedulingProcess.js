/**
 * Created by Kip on 11/12/2018.
 */
Ext.define('Admin.view.premiseregistration.views.maininterfaces.premisesinspection.PremisesinspectionschedulingProcess', {
    extend: 'Ext.panel.Panel',
    xtype: 'premisesinspectionschedulingprocess',
    layout:'fit',
    items: [
        {
            xtype: 'premisesinspectionscheduling'
        }
    ]
});
/**
 * Created by Kip on 11/26/2018.
 */
Ext.define('Admin.view.premiseregistration.views.sharedinterfaces.panels.RenewPremisePaymentsPanel', {
    extend: 'Admin.view.commoninterfaces.PaymentsPanel',
    xtype: 'renewpremisepaymentspanel'
});
/**
 * Created by Kip on 12/13/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.alteration.AltPremiseCommunicationPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.AltPremiseCommunicationPanel',
    xtype: 'altpremisecommunicationpnl'
});
/**
 * Created by Kip on 11/12/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.new.NewPremiseScreeningPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.NewPremiseScreeningPanel',
    xtype: 'newpremisescreeningpnl'
});
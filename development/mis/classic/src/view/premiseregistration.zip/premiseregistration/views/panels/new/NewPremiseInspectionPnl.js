/**
 * Created by Kip on 11/12/2018.
 */
Ext.define('Admin.view.premiseregistration.views.panels.new.NewPremiseInspectionPnl', {
    extend: 'Admin.view.premiseregistration.views.sharedinterfaces.panels.NewPremiseInspectionPanel',
    xtype: 'newpremiseinspectionpnl'
});
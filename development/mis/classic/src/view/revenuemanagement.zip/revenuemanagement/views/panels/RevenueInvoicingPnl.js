/**
 * Created by Kip on 10/12/2018.
 */

Ext.define('Admin.view.revenuemanagement.views.panels.RevenueInvoicingPnl', {
    extend: 'Admin.view.commoninterfaces.InvoicingPanel',
    xtype: 'revenueinvoicingpnl',
});
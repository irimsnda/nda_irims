Ext.define('Admin.view.RevenueManagement.views.grids.CustomerSelectionGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicantSelectionCmnGrid',
    controller: 'revenueManagementVctr',
    xtype: 'customerSelectionGrid',
    
});

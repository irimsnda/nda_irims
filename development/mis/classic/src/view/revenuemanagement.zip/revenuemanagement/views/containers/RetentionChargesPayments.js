/**
 * created by softclans
 * user robinson odhiambo
 */
Ext.define('Admin.view.revenuemanagement.views.containers.RetentionChargesPayments', {
    extend: 'Ext.Container',
    xtype: 'retentionchargespayments',
    controller: 'revenuemanagementvctr',
    layout: 'fit',
    items: [
        {
            xtype: 'retentionchargespaymentspnl'
        }
    ]
});//medicaldevicesnoficationmanagerreview
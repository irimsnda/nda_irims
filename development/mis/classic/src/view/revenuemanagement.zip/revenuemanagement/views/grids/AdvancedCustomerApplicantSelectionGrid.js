
Ext.define('Admin.view.RevenueManagement.views.grids.AdvancedCustomerApplicantSelectionGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicantSelectionCmnGrid',
    controller: 'revenuemanagementvctr',
    xtype: 'advancedCustomerApplicantSelectionGrid'
});

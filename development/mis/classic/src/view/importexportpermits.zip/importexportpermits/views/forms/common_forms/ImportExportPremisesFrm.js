/**
 * Created by Softclans
 * User robinson odhiambo
 * on 9/24/2018.
 */
Ext.define('Admin.view.importexportpermits.views.forms.common_forms.ImportExportPremisesFrm', {
    extend: 'Admin.view.commoninterfaces.forms.PremiseDetailsCmnFrm',
    xtype: 'importexportpremisesfrm',
    itemId: 'importexportpremisesfrm'
});


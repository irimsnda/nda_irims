/**
 * Created by softclans
 * user robinson odhiambo
 * Kip on 9/24/2018. 
 */
Ext.define('Admin.view.importexportpermits.views.sharedinterfaces.panels.ControlledDrugsPaymentVerificationPnl', {
    alias: 'widget.controlleddrugspaymentverificationpnl',
    extend: 'Admin.view.commoninterfaces.PaymentVerificationPnl',
   
});

Ext.define('Admin.view.Enforcement.views.grids.InternalUsersSelectionGrid', {
    extend: 'Admin.view.commoninterfaces.grids.InternalUsersGrid',
    controller: 'enforcementvctr',
    xtype: 'internalUsersSelectionGrid',  
});

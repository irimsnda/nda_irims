Ext.define('Admin.view.Enforcement.views.grids.EnforcementApplicantSelectionGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicantSelectionCmnGrid',
    controller: 'enforcementvctr',
    xtype: 'enforcementApplicantSelectionGrid',
    
});

/**
 * Created by Kip on 1/26/2019.
 */
Ext.define('Admin.view.productregistration.views.forms.common_forms.ProductMeetingDetailsFrm', {
    extend: 'Admin.view.commoninterfaces.views.forms.MeetingDetailsFrm',
    xtype: 'productMeetingDetailsFrm',
   
});
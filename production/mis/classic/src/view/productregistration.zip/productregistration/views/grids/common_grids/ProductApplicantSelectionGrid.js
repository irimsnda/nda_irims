/**
 * Created by Softclans
 * Kip on 9/26/2018.
 */
Ext.define('Admin.view.productregistration.views.grids.common_grids.ProductApplicantSelectionGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicantSelectionCmnGrid',
    controller: 'productregistrationvctr',
    xtype: 'productapplicantselectiongrid',
    
});

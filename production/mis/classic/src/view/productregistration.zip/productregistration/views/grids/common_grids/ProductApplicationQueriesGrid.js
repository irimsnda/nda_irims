/**
 * Created by Kip on 10/17/2018.
 */
Ext.define('Admin.view.productregistration.views.grids.common_grids.ProductApplicationQueriesGrid', {
    extend:'Admin.view.commoninterfaces.grids.AllQueriesGrid',
    xtype: 'productapplicationqueriesgrid',
   
});

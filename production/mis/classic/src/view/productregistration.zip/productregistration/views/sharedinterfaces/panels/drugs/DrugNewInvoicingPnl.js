/**
 * Created by Kip on 10/12/2018.
 */
Ext.define('Admin.view.productregistration.views.panels.drugs.DrugNewInvoicingPnl', {
    extends: 'Admin.view.commoninterfaces.InvoicingPanel',
    xtype: 'drugnewinvoicingpnl'
});
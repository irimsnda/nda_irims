/**
 * Created by softclans
 * user robinson odhiambo
 * on 10/4/2018.
 */
Ext.define('Admin.view.productregistration.views.forms.common_forms.ProductDocUploadsFrm', {
    extend: 'Admin.view.commoninterfaces.forms.ApplicationDocUploadsFrm',
    xtype: 'productDocUploadsFrm',
    frame: true
     
});
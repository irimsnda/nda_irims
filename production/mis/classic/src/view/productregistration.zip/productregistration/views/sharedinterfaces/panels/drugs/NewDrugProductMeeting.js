/**
 * Created by Kip on 10/14/2018.
 */
Ext.define('Admin.view.productregistration.views.sharedinterfaces.panels.drugs.NewDrugProductMeeting', {
    extend:'Admin.view.productregistration.views.sharedinterfaces.panels.common_panels.NewProductTcMeetingPnl',
    xtype: 'newDrugProductMeeting',
    
});
/**
 * Created by Softclans
 * User robinson odhiambo
 * on 10/4/2018.
 */
Ext.define('Admin.view.productregistration.views.grids.common_grids.ProductQueryResponseUploadsGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicationDocUploadsGrid',
    xtype:'productqueryresponseuploadsgrid',
    upload_tab:'productqueryresponseuploadsgrid',
    table_name: 'tra_product_applications',
});

/**
 * Created by Kip on 9/24/2018.
 */
Ext.define('Admin.view.productregistration.views.maininterfaces.drugs.dataammendment.MedicineProductDataAmmendRequest', {
    extend: 'Ext.panel.Panel',
    xtype: 'medicineproductdataammendrequest',
    controller: 'productregistrationvctr',
    viewModel: 'productregistrationvm',
    layout: 'fit',
    items: [
        {
            xtype: 'medicineproductdataammendrequestwizard'
        }
    ]
});